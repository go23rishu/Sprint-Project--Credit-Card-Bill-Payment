export class Account {
    accountNumber: number;
    accountName: string;
    balance: number;
    type: string;
}
